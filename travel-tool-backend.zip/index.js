const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const trips = [
  { id: 1, name: 'Manali Trip', days: 5 },
  { id: 2, name: 'Goa Vacation', days: 7 }
];

app.get('/', (req, res) => {
  res.send('Travel Tool Backend is running!');
});

app.get('/api/trips', (req, res) => {
  res.json(trips);
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
